<?php
	include 'datastruct.php';
	include 'crawler.php';
	
	$start = microtime(true);

	$searcher = new InvertedIndex();
	$crawler = new Crawler();
	$dirName = "docs";
	
	$dir = opendir($dirName);
	//empty the directory in preparation for new documents
	
	while (false !== ($entry = readdir($dir))) 
	{
		if(	"." != $entry && ".." != $entry)
		{
			unlink("$dirName/".$entry);
		}
	}
	
	
	
	//Crawl pages
	$crawler->seed = "http://www.eecs.ku.edu";
	$crawler->maxDepth = 5;
	$crawler->domain = "eecs.ku.edu";
	$crawler->dir = "$dirName/"; //all files will be stored in the docs directory.  Make sure it's created before crawling
	$crawler->crawl(array($crawler->seed));
	
	rewinddir($dir);

			
	//Page rank all documents
	while (false !== ($entry = readdir($dir))) 
	{
		if(	"." != $entry && 
			".." != $entry  && 
			preg_match('#html*?#',$entry) >0)
		{		
			//echo "analyzing $entry <br/>";
			$searcher->ConstructDictionary($entry, sanitize("$dirName/".$entry));
		}   
	}
	

	
	closedir($dir);	
	
	
	file_put_contents("crawler", serialize($crawler));
	file_put_contents("searcher",serialize($searcher));
	
	$totalTime = number_format( (microtime(true)-$start), 3);
	
	echo "<h1> Preprocessing finished</h1>";
	echo count($crawler->crawledPages) . " collected and indexed from " . $crawler->domain .  " in " . number_format( (microtime(true)-$start), 3) . " seconds <br/>";
	/*
		TESTING
	$crawlerData = file_get_contents('crawler');
	$crawler = unserialize($crawlerData);
	
	$searcherData = file_get_contents('searcher');
	$searcher = unserialize($searcherData);
	
	var_dump($crawler);
	echo "<hr/>";
	var_dump($searcher);
	*/
?>