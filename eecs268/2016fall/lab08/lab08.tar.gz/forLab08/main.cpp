#include <iostream>
#include <string>

#include "BinarySearchTree.h"

int main(int argc, char* argv[])
{
	//Example declaration of a BST
	//BinarySearchTree<Pokemon , std::string> bst;
	//Example adding 
	//Pokemon p("Bulbasaur", 1, "Bulbasaur");
	//bst.add(p);

	return 0;
}